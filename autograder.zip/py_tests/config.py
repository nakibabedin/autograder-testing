from os import path

EXCECUTION_DIR = path.join('..', 'execution')