#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "test_module/external/doctest.h"

// Include all submission files
#include "submission_module/submission_module.hpp"

