#! /usr/bin/env bash
rm autograder.zip

zip -r autograder.zip ./*